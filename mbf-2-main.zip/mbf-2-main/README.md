<img src="https://github.com/Yayan-XD/mbf-2/blob/main/Ngentod/wallpaperbetter_(1).jpg" width="640" title="Menu" alt="Menu">
</p>
 <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Yayan-XD/mbf-2.svg"/>
  </a>

 <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Yayan-XD/mbf-2.svg"/>
  </a>

<h1 align="center">
  mbf-2
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://www.facebook.com/KM39453">YayanXD_</a>
</p>
<p align="center">
 <img src="https://github.com/Yayan-XD/mbf-2/blob/main/Ngentod/IMG_20210222_124322.jpg" width="640" title="Menu" alt="Menu">
</p>

<a href="https://github.com/Yayan-XD/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Yayan-XD?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Yayan-XD/termux-style/stargazers/">
  <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Yayan-XD/mbf-2.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Yayan-XD/mbf-2.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Search" src="https://img.shields.io/github/search/Yayan-XD/Craker/mbf-2.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Starts" src="https://img.shields.io/github/stars/Yayan-XD/mbf-2.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/mbf-2">
    <img alt="Forks" src="https://img.shields.io/github/forks/Yayan-XD/mbf-2.svg"/>
  </a>
</div>
<p align="center">

## Install script on Termux
```python
$ pkg update && pkg upgrade
$ pkg install python2
$ pip2 install requests bs4
$ pkg install git
$ git clone https://github.com/Yayan-XD/mbf-2
```

## Run script
```python
$ cd mbf-2
$ python2 crack.py
```

## Informasi For Updates Script
* V1 {Dump Id Friends lists}
* V2 {Dump Id Friends}
* V3 {Dump Id by Search name}
* V4 {Dump Id like status}
* V5 {Start crack}
* V6 {Remove cookies}
* V07 {Update Tools}
* V0 {Exit}
*  Mutli type login
*   - [Cokies](https://youtu.be/72zvkSbVPOI)

#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Yayan-XD) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/moch_xd)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/KM39453)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/yayanxd_/) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285603036683?text=Asalamualaikum+bang)

#### Donate :

<a href="https://saweria.co/YayanXD"><img src="https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_dana_blue.svg" alt="alt text" width="80" height="80"></a> &nbsp;&nbsp;

* Notice Me : Please Don't Change Name Author
Thanks For Using My Script
